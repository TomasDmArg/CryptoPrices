const obtain = ()=>{

}

export default obtain;
// obtain
// let aCookie;
// let aCookies = document.cookie.split(";");
// console.log(aCookies)
// console.log(aCookies[2])
// if (aCookies[2] === " Theme=dark") {
//     console.log('Dark')
//     darkMode();
// }
// if (aCookies[2] === " Theme=light") {
//     console.log('light')
//     lightMode();
// }
// applyMode();
// const changeMode = ()=>{
//     (state) ? darkMode() : lightMode()
// }
// const nightMode = $('#nightMode');
// let tState = 0;
// const toggle = el =>{
//     el.addEventListener('click', ()=>{
//         if (tState === 1) {
//             tState--;
//         }else{
//             tState++;
//         }
        
//         changeMode();
        
//     });
// }
// toggle(nightMode);



