export const $ = sel => document.querySelector(sel);
export const $$ = sel => document.querySelectorAll(sel);
export const body = $('.body');
export const logo = $('#logoContainer');
export const allText = $$('.text');
