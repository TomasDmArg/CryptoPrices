const contactHTML = `
<h1> Formulario</h1>
`;
export default contactHTML;