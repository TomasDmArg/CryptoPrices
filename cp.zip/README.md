# CryptoPrices
##### www.cryptoprices.com.ar

### Ver presentación: https://tmdm.com.ar/u/cryptoprices.pdf

Crypto Prices es un sitio web (SPA) Open Source de criptomonedas enfocado a argentinos, tanto personas como empresas o pequeños emprendedores. 
Permite ver precios de los distintos dólares (crypto y no crypto), ver precios de criptomonedas tanto en dólares como en pesos (al tipo de cambio real)(+9000 monedas)
Convertir las mismas, ver gráficos, estadisticas y demás. 
Es el único sitio web (conocido) que posee tantas criptomonedas para ver y está adaptada al dolar real, y a su vez integra los precios de los diferentes tipos de 
dolar, para evitar que se tenga que recurrir a dos páginas para ver esto

Posee un apartado para negocios (en desarrollo), que permite poner un monto en pesos argentinos, elegir una moneda, y te genera el monto que te debería enviar 
el cliente, y en caso de ser necesario pedir un cuil/dni ycorreo al cliente, si se recibió el dinero, se confirma y se envía un correo con un comprobante. Ideal
para complementar con otro procesador de pagos, ya que estos solo aceptan poner monto en usd o pesos al valor oficial

No se guardan ni se envía ningun dato, todo es guardado a través de cookies de forma local, y los comprobantes se puede elegir no enviarlos.

## Funciones pendientes
- Terminar parte de negocios
- Crear modo HTML simple para conexiones lentas
- Agregar sección "Mercados Locales" en páginas individuales
- Agregar sección "Mercados Extranjeros" en páginas individuales
- Sección de "Blog"
