const getValue = ()=>{
    //
}
export default getValue;